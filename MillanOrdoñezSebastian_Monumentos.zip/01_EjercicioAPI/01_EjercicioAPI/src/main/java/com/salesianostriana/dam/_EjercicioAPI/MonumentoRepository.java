package com.salesianostriana.dam._EjercicioAPI;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MonumentoRepository extends JpaRepository<Monumento, Long> {
}
