package com.salesianostriana.dam.EjercicioDTOPareja.model;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DireccionRepository extends JpaRepository<Direccion, Long> {
}
