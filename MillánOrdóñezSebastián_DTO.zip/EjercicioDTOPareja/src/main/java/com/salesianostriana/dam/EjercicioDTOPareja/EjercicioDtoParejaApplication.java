package com.salesianostriana.dam.EjercicioDTOPareja;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjercicioDtoParejaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjercicioDtoParejaApplication.class, args);
	}

}
