package com.salesianostriana.dam.EjercicioDTOPareja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioDtoParejaApplicationTests {

	@Test
	void contextLoads() {
	}

}
